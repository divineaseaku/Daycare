function openSlideMenu(){
  document.getElementById('side-menu').style.width = '290px';
  document.getElementById('side-menu').style.display = 'block';
   
}
  function closeSlideMenu(){
    document.getElementById('side-menu').style.width = '0px';
  }